import random

# Fixed seed for determinism
random.seed(42)

# Candidate warehouse locations in Maharashtra
CANDIDATE_WAREHOUSES = [
    {"id": "WH-MUM", "name": "Mumbai Hub", "latitude": 19.0760, "longitude": 72.8777, "baseline_capacity": 20000},
    {"id": "WH-PUN", "name": "Pune Hub", "latitude": 18.5204, "longitude": 73.8567, "baseline_capacity": 15000},
    {"id": "WH-NSK", "name": "Nashik Hub", "latitude": 20.0110, "longitude": 73.7903, "baseline_capacity": 10000},
    {"id": "WH-NGP", "name": "Nagpur Hub", "latitude": 21.1458, "longitude": 79.0882, "baseline_capacity": 15000},
    {"id": "WH-AUR", "name": "Aurangabad Hub", "latitude": 19.8762, "longitude": 75.3433, "baseline_capacity": 12000},
    {"id": "WH-SOL", "name": "Solapur Hub", "latitude": 17.6599, "longitude": 75.9064, "baseline_capacity": 8000},
    {"id": "WH-KOL", "name": "Kolhapur Hub", "latitude": 16.7050, "longitude": 74.2433, "baseline_capacity": 8000},
    {"id": "WH-AMR", "name": "Amravati Hub", "latitude": 20.9320, "longitude": 77.7523, "baseline_capacity": 6000},
]

def generate_customers(num_customers=50):
    # Generating deterministic customers around the candidate hubs
    customers = []
    for i in range(num_customers):
        # Pick a random hub to center the customer around
        hub = random.choice(CANDIDATE_WAREHOUSES)
        
        # Add some random jitter (approx +/- 0.5 degrees lat/lon ~ 50km)
        lat_jitter = (random.random() - 0.5) * 1.0
        lon_jitter = (random.random() - 0.5) * 1.0
        
        lat = hub["latitude"] + lat_jitter
        lon = hub["longitude"] + lon_jitter
        
        # Demand from 100 to 1000
        demand = random.randint(10, 100) * 10
        
        customers.append({
            "id": f"C-{i+1:03d}",
            "latitude": round(lat, 4),
            "longitude": round(lon, 4),
            "demand": demand
        })
    return customers

CUSTOMERS = generate_customers(50)

def get_demo_data():
    return {
        "warehouses": CANDIDATE_WAREHOUSES,
        "customers": CUSTOMERS
    }
