import math
import itertools
from typing import Dict, List, Any

# Haversine formula
def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371.0 # Earth radius in kilometers
    dLat = math.radians(lat2 - lat1)
    dLon = math.radians(lon2 - lon1)
    a = (math.sin(dLat / 2) * math.sin(dLat / 2) +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dLon / 2) * math.sin(dLon / 2))
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def _evaluate_single_ordering(
    selected_warehouses: List[Dict],
    customers: List[Dict],
    capacity_limit: float,
    max_radius: float,
    objective: str,
    ordering_heuristic: str
) -> Dict:
    """
    Agent 3 uses deterministic heuristic assignment; it does not guarantee globally optimal 
    customer-to-warehouse assignment.
    """
    wh_capacity_used = {wh['id']: 0 for wh in selected_warehouses}
    assignments = []
    
    total_demand = sum(c['demand'] for c in customers)
    served_demand = 0
    total_distance_km = 0.0
    
    # Sort customers based on heuristic
    if ordering_heuristic == "largest_first":
        sorted_customers = sorted(customers, key=lambda c: (-c['demand'], c['id']))
    elif ordering_heuristic == "smallest_first":
        sorted_customers = sorted(customers, key=lambda c: (c['demand'], c['id']))
    elif ordering_heuristic == "nearest_first":
        # Sort by distance to nearest candidate warehouse
        def nearest_dist(c):
            return min([haversine(c['latitude'], c['longitude'], wh['latitude'], wh['longitude']) for wh in selected_warehouses])
        sorted_customers = sorted(customers, key=lambda c: (nearest_dist(c), c['id']))
    else:
        sorted_customers = customers

    for c in sorted_customers:
        feasible_whs = []
        for wh in selected_warehouses:
            dist = haversine(c['latitude'], c['longitude'], wh['latitude'], wh['longitude'])
            if max_radius is not None and dist > max_radius:
                continue
            
            avail_cap = None
            if capacity_limit is not None:
                avail_cap = capacity_limit - wh_capacity_used[wh['id']]
                if avail_cap < c['demand']:
                    continue # Cannot fully serve this customer
            
            feasible_whs.append((dist, wh))
            
        if not feasible_whs:
            continue # Unserved
            
        # Tie-breaker: sort by distance, then warehouse ID
        feasible_whs.sort(key=lambda x: (x[0], x[1]['id']))
        best_dist, best_wh = feasible_whs[0]
        
        # Assign
        wh_capacity_used[best_wh['id']] += c['demand']
        served_demand += c['demand']
        total_distance_km += best_dist * c['demand'] # Demand-weighted distance
        
        assignments.append({
            "customer_id": c['id'],
            "warehouse_id": best_wh['id'],
            "demand": c['demand'],
            "distance_km": round(best_dist, 2)
        })
        
    unserved_demand = total_demand - served_demand
    coverage_percent = (served_demand / total_demand * 100) if total_demand > 0 else 0
    
    cost_per_unit_km = 1.5
    total_cost = total_distance_km * cost_per_unit_km
    
    utils = []
    warehouse_results = []
    for wh in selected_warehouses:
        used = wh_capacity_used[wh['id']]
        cap = capacity_limit if capacity_limit is not None else wh['baseline_capacity']
        util = (used / cap * 100) if cap > 0 else 0
        utils.append(util)
        
        warehouse_results.append({
            "id": wh['id'],
            "latitude": wh['latitude'],
            "longitude": wh['longitude'],
            "capacity": cap,
            "assigned_demand": used,
            "utilization_percent": round(util, 2)
        })
        
    avg_util = sum(utils) / len(utils) if utils else 0
    
    return {
        "warehouses": warehouse_results,
        "assignments": assignments,
        "metrics": {
            "total_demand": total_demand,
            "served_demand": served_demand,
            "unserved_demand": unserved_demand,
            "coverage_percent": round(coverage_percent, 2),
            "total_demand_weighted_distance_km_units": round(total_distance_km, 2),
            "total_cost": round(total_cost, 2),
            "cost_currency": "INR",
            "average_utilization_percent": round(avg_util, 2)
        },
        # These will be re-evaluated later
        "constraints": {
            "capacity_respected": True,
            "radius_respected": True
        }
    }

def _compare_assignments(res1: Dict, res2: Dict, objective: str) -> Dict:
    """Returns the better result based on the objective."""
    if res1 is None:
        return res2
    if res2 is None:
        return res1

    m1 = res1['metrics']
    m2 = res2['metrics']

    # HARD CONSTRAINTS: prefer solutions with all demand served.
    full1 = m1['unserved_demand'] == 0
    full2 = m2['unserved_demand'] == 0

    if objective == "maximize_coverage":
        # 1. maximum served_demand
        # 2. minimum demand-weighted distance as tie-breaker.
        if m1['served_demand'] != m2['served_demand']:
            return res1 if m1['served_demand'] > m2['served_demand'] else res2
        return res1 if m1['total_demand_weighted_distance_km_units'] < m2['total_demand_weighted_distance_km_units'] else res2

    if objective in ["minimize_distance", "minimize_cost"]:
        # Primary: full feasibility (unserved_demand == 0)
        if full1 and not full2:
            return res1
        elif full2 and not full1:
            return res2
        
        # Both fully feasible or both partially feasible:
        # If both are partial, we still optimize objective or max served demand as fallback.
        # But for full feasibility, we prefer the one with the lowest cost/distance.
        val1 = m1['total_demand_weighted_distance_km_units'] if objective == "minimize_distance" else m1['total_cost']
        val2 = m2['total_demand_weighted_distance_km_units'] if objective == "minimize_distance" else m2['total_cost']
        
        if val1 != val2:
            return res1 if val1 < val2 else res2
        return res1 if m1['served_demand'] > m2['served_demand'] else res2

    if objective == "balanced":
        # Primary: full feasibility
        if full1 and not full2:
            return res1
        elif full2 and not full1:
            return res2
            
        # Demo configurable weighting: 80% coverage, 20% efficiency
        max_dist_1 = m1['total_demand'] * 1000
        norm_dist_1 = m1['total_demand_weighted_distance_km_units'] / max_dist_1 if max_dist_1 > 0 else 0
        norm_cov_1 = m1['served_demand'] / m1['total_demand'] if m1['total_demand'] > 0 else 0
        score_1 = (1.0 - norm_cov_1) * 0.8 + norm_dist_1 * 0.2

        max_dist_2 = m2['total_demand'] * 1000
        norm_dist_2 = m2['total_demand_weighted_distance_km_units'] / max_dist_2 if max_dist_2 > 0 else 0
        norm_cov_2 = m2['served_demand'] / m2['total_demand'] if m2['total_demand'] > 0 else 0
        score_2 = (1.0 - norm_cov_2) * 0.8 + norm_dist_2 * 0.2
        
        return res1 if score_1 < score_2 else res2

    return res1

def optimize_scenario(scenario: Dict[str, Any], data: Dict[str, Any] = None) -> Dict[str, Any]:
    if data is None:
        try:
            from agent3.demo_data import get_demo_data
            data = get_demo_data()
        except ImportError:
            return {"status": "error", "feasible": False, "reason": "No data provided and demo_data not found."}
            
    warehouses = data.get('warehouses', [])
    customers = data.get('customers', [])
    
    # 1. EMPTY DATA VALIDATION
    if not warehouses:
        return {"status": "error", "feasible": False, "reason": "No candidate locations available in region."}
    if not customers:
        return {"status": "error", "feasible": False, "reason": "No customer demand data available."}
        
    # 2. DATA NORMALIZATION AND VALIDATION
    normalized_warehouses = []
    for i, w in enumerate(warehouses):
        try:
            lat = float(w['latitude'])
            lon = float(w['longitude'])
            if math.isnan(lat) or math.isinf(lat) or math.isnan(lon) or math.isinf(lon):
                return {"status": "error", "feasible": False, "reason": "NaN or Inf in warehouse coordinates."}
            if lat < -90 or lat > 90:
                return {"status": "error", "feasible": False, "reason": "Warehouse latitude must be between -90 and 90."}
            if lon < -180 or lon > 180:
                return {"status": "error", "feasible": False, "reason": "Warehouse longitude must be between -180 and 180."}
            # Also normalize baseline_capacity if used
            cap = float(w.get('baseline_capacity', 0))
            if math.isnan(cap) or math.isinf(cap):
                return {"status": "error", "feasible": False, "reason": "NaN or Inf in warehouse baseline_capacity."}
                
            norm_w = w.copy()
            norm_w['latitude'] = lat
            norm_w['longitude'] = lon
            norm_w['baseline_capacity'] = cap
            normalized_warehouses.append(norm_w)
        except (ValueError, TypeError):
            return {"status": "error", "feasible": False, "reason": "Warehouse coordinates must be numeric."}
            
    normalized_customers = []
    for i, c in enumerate(customers):
        try:
            lat = float(c['latitude'])
            lon = float(c['longitude'])
            demand = float(c['demand'])
            if math.isnan(lat) or math.isinf(lat) or math.isnan(lon) or math.isinf(lon):
                return {"status": "error", "feasible": False, "reason": "NaN or Inf in customer coordinates."}
            if lat < -90 or lat > 90:
                return {"status": "error", "feasible": False, "reason": "Customer latitude must be between -90 and 90."}
            if lon < -180 or lon > 180:
                return {"status": "error", "feasible": False, "reason": "Customer longitude must be between -180 and 180."}
            if math.isnan(demand) or math.isinf(demand):
                return {"status": "error", "feasible": False, "reason": "NaN or Inf in customer demand."}
            if demand < 0:
                return {"status": "error", "feasible": False, "reason": "Customer demand must be >= 0."}
                
            norm_c = c.copy()
            norm_c['latitude'] = lat
            norm_c['longitude'] = lon
            norm_c['demand'] = demand
            normalized_customers.append(norm_c)
        except (ValueError, TypeError):
            return {"status": "error", "feasible": False, "reason": "Customer coordinates and demand must be numeric."}

    warehouses = normalized_warehouses
    customers = normalized_customers

    warehouse_count = scenario.get("warehouse_count")
    capacity = scenario.get("capacity")
    max_radius = scenario.get("max_radius")
    objective = scenario.get("objective", "minimize_distance")
    
    # 3. OBJECTIVE VALIDATION
    valid_objectives = ["minimize_distance", "minimize_cost", "maximize_coverage", "balanced"]
    if objective not in valid_objectives:
         return {"status": "error", "feasible": False, "reason": f"Unknown objective: {objective}. Valid: {valid_objectives}"}

    # Handle negative values
    if warehouse_count is not None and warehouse_count <= 0:
        return {"status": "error", "feasible": False, "reason": "warehouse_count must be > 0"}
    if capacity is not None and capacity <= 0:
        return {"status": "error", "feasible": False, "reason": "capacity must be > 0"}
    if max_radius is not None and max_radius < 0:
        return {"status": "error", "feasible": False, "reason": "max_radius must be >= 0"}
        
    total_demand = sum(c['demand'] for c in customers)
    
    # 4. WAREHOUSE COUNT DERIVATION
    warehouse_count_requested = warehouse_count
    warehouse_count_used = warehouse_count
    
    if warehouse_count is None:
        if capacity is not None:
            derived_w = math.ceil(total_demand / capacity)
        else:
            sorted_whs = sorted(warehouses, key=lambda w: w['baseline_capacity'], reverse=True)
            acc_cap = 0
            derived_w = 0
            for w in sorted_whs:
                acc_cap += w['baseline_capacity']
                derived_w += 1
                if acc_cap >= total_demand:
                    break
        
        if derived_w > len(warehouses):
            return {
                "status": "infeasible", 
                "feasible": False, 
                "reason": f"Derived warehouse count ({derived_w}) exceeds available candidates ({len(warehouses)})."
            }
            
        warehouse_count_used = max(1, derived_w)
    
    if warehouse_count_used > len(warehouses):
        return {"status": "infeasible", "feasible": False, "reason": f"Requested {warehouse_count_used} warehouses but only {len(warehouses)} candidates exist."}

    best_result = None
    
    # Exhaustive subset evaluation with 3 greedy assignments per subset
    heuristics = ["largest_first", "smallest_first", "nearest_first"]
    
    for subset in itertools.combinations(warehouses, warehouse_count_used):
        subset_list = list(subset)
        subset_best = None
        for h in heuristics:
            res = _evaluate_single_ordering(subset_list, customers, capacity, max_radius, objective, h)
            subset_best = _compare_assignments(subset_best, res, objective)
            
        best_result = _compare_assignments(best_result, subset_best, objective)
                
    if best_result is None:
        return {"status": "infeasible", "feasible": False, "reason": "No valid assignment found."}
        
    # Check if we served everything
    feasible = best_result['metrics']['unserved_demand'] == 0
    
    # Validate constraints explicitly from the final result
    cap_respected = True
    for wh in best_result['warehouses']:
        if capacity is not None and wh['assigned_demand'] > capacity:
            cap_respected = False
            
    rad_respected = True
    for a in best_result['assignments']:
        if max_radius is not None and a['distance_km'] > max_radius:
            rad_respected = False
            
    best_result['constraints']['capacity_respected'] = cap_respected
    best_result['constraints']['radius_respected'] = rad_respected
    
    feasible = feasible and cap_respected and rad_respected
    status = "optimized" if feasible else "partially_served"
    
    output = {
        "status": status,
        "feasible": feasible,
        "solution_type": "optimized",
        "objective": objective,
        "warehouse_count_requested": warehouse_count_requested,
        "warehouse_count_used": warehouse_count_used,
        "warehouses": best_result['warehouses'],
        "assignments": best_result['assignments'],
        "metrics": best_result['metrics'],
        "constraints": best_result['constraints']
    }
    
    return output
