import unittest
import json
from agent3.optimizer import optimize_scenario

class TestAgent3(unittest.TestCase):
    def test_minimize_distance(self):
        scenario = {
            "business_type": "electronics",
            "region": "Maharashtra",
            "warehouse_count": 4,
            "objective": "minimize_distance",
            "capacity": 10000,
            "max_radius": 60
        }
        result = optimize_scenario(scenario)
        
        self.assertEqual(result["objective"], "minimize_distance")
        self.assertEqual(len(result["warehouses"]), 4)
        
        # Assert JSON serializable
        json.dumps(result)

    def test_maximize_coverage(self):
        scenario = {
            "warehouse_count": 2,
            "objective": "maximize_coverage",
            "capacity": None,
            "max_radius": 50
        }
        result = optimize_scenario(scenario)
        self.assertEqual(result["objective"], "maximize_coverage")
        self.assertEqual(len(result["warehouses"]), 2)

    def test_balanced_null_count(self):
        scenario = {
            "warehouse_count": None,
            "objective": "balanced",
            "capacity": 10000,
            "max_radius": None
        }
        result = optimize_scenario(scenario)
        self.assertEqual(result["objective"], "balanced")
        self.assertGreater(len(result["warehouses"]), 0)
        self.assertIsNone(result["warehouse_count_requested"])
        self.assertIsNotNone(result["warehouse_count_used"])

    def test_infeasible_capacity(self):
        scenario = {
            "warehouse_count": 1,
            "objective": "minimize_distance",
            "capacity": 10,  # Ridiculously small
            "max_radius": None
        }
        result = optimize_scenario(scenario)
        self.assertEqual(result["status"], "partially_served")
        self.assertFalse(result["feasible"])
        self.assertTrue(result["constraints"]["capacity_respected"])

    def test_infeasible_radius(self):
        scenario = {
            "warehouse_count": 1,
            "objective": "minimize_distance",
            "capacity": None,
            "max_radius": 1  # 1 km is too small to serve anyone except maybe jitter zero
        }
        result = optimize_scenario(scenario)
        self.assertEqual(result["status"], "partially_served")
        self.assertFalse(result["feasible"])

    def test_zero_radius(self):
        scenario = {
            "warehouse_count": 1,
            "objective": "minimize_distance",
            "capacity": None,
            "max_radius": 0
        }
        result = optimize_scenario(scenario)
        # Should be partially served since customers aren't directly on top of warehouses
        self.assertEqual(result["status"], "partially_served")
        self.assertFalse(result["feasible"])

    def test_invalid_negative(self):
        scenario = {
            "warehouse_count": -2,
            "objective": "minimize_distance"
        }
        result = optimize_scenario(scenario)
        self.assertEqual(result["status"], "error")
        
    def test_invalid_objective(self):
        scenario = {
            "warehouse_count": 2,
            "objective": "maximize_profit"
        }
        result = optimize_scenario(scenario)
        self.assertEqual(result["status"], "error")
        self.assertIn("Unknown objective", result["reason"])

    def test_empty_data(self):
        scenario = {
            "warehouse_count": 1,
            "objective": "minimize_distance"
        }
        result = optimize_scenario(scenario, data={"warehouses": [], "customers": []})
        self.assertEqual(result["status"], "error")
        self.assertFalse(result["feasible"])
        self.assertIn("No candidate locations available", result["reason"])

    def test_nan_demand(self):
        scenario = {
            "warehouse_count": 1,
            "objective": "minimize_distance"
        }
        data = {
            "warehouses": [{"id": "W1", "latitude": 10.0, "longitude": 10.0, "baseline_capacity": 100}],
            "customers": [{"id": "C1", "latitude": 10.1, "longitude": 10.1, "demand": float('nan')}]
        }
        result = optimize_scenario(scenario, data=data)
        self.assertEqual(result["status"], "error")
        self.assertIn("NaN or Inf", result["reason"])

    def test_string_demand(self):
        scenario = {
            "warehouse_count": 1,
            "objective": "minimize_distance"
        }
        data = {
            "warehouses": [{"id": "W1", "latitude": 10.0, "longitude": 10.0, "baseline_capacity": 100}],
            "customers": [{"id": "C1", "latitude": 10.1, "longitude": 10.1, "demand": "lots"}]
        }
        result = optimize_scenario(scenario, data=data)
        self.assertEqual(result["status"], "error")
        self.assertIn("must be numeric", result["reason"])

    def test_invalid_latitude(self):
        scenario = {
            "warehouse_count": 1,
            "objective": "minimize_distance"
        }
        data = {
            "warehouses": [{"id": "W1", "latitude": 100.0, "longitude": 10.0, "baseline_capacity": 100}],
            "customers": [{"id": "C1", "latitude": 10.1, "longitude": 10.1, "demand": 10}]
        }
        result = optimize_scenario(scenario, data=data)
        self.assertEqual(result["status"], "error")
        self.assertIn("must be between -90 and 90", result["reason"])

    def test_deterministic_repeatability(self):
        scenario = {
            "warehouse_count": 3,
            "objective": "minimize_cost",
            "capacity": 15000,
            "max_radius": 100
        }
        result1 = optimize_scenario(scenario)
        result2 = optimize_scenario(scenario)
        
        self.assertEqual(json.dumps(result1, sort_keys=True), json.dumps(result2, sort_keys=True))

if __name__ == "__main__":
    unittest.main()
