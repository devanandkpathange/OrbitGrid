import json
from transformers import AutoTokenizer
from unsloth import FastLanguageModel
from agent3.optimizer import optimize_scenario
import torch

def test_e2e():
    print("Loading Agent 2 (Fine-tuned model)...")
    model_dir = r"D:\AI\unsloth-studio\outputs\unsloth_Llama-3.2-1B-Instruct__project-gridpoint-scenario-lora-v1_1789879869"
    
    # Load model using Unsloth
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=model_dir,
        max_seq_length=2048,
        dtype=None,
        load_in_4bit=True,
    )
    FastLanguageModel.for_inference(model)

    user_query = "I run an electronics business in Maharashtra. I need 4 warehouses, each with capacity of 10000 units. Customers should be within 60 km. Minimize transportation distance."
    
    instruction = (
        "Extract the following fields from the user scenario: "
        "business_type, region, warehouse_count, objective (minimize_distance, minimize_cost, maximize_coverage, or balanced), "
        "capacity, and max_radius. Output valid JSON only.\n\n"
        f"Scenario: {user_query}"
    )

    messages = [
        {"role": "user", "content": instruction}
    ]

    print("\nRunning Agent 2 (Information Extraction)...")
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer([text], return_tensors="pt").to("cuda")

    with torch.inference_mode():
        outputs = model.generate(**inputs, max_new_tokens=512, do_sample=False)
    
    response_text = tokenizer.decode(outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
    
    print("\nAgent 2 Output:")
    print(response_text)

    try:
        scenario = json.loads(response_text)
    except json.JSONDecodeError:
        import ast
        try:
            scenario = ast.literal_eval(response_text)
        except Exception:
            print("Failed to parse Agent 2 output as JSON.")
            return

    print("\nRunning Agent 3 (Optimization)...")
    result = optimize_scenario(scenario)
    
    print("\nAgent 3 Output:")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    test_e2e()
